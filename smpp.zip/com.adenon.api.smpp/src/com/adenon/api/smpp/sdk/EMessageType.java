package com.adenon.api.smpp.sdk;


public enum EMessageType {
    SMSText,
    SMSBinary,
    WAPPushSI,
    WAPPushSL,
    USSD,
    WAPBookmark
}
