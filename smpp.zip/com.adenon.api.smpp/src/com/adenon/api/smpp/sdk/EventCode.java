package com.adenon.api.smpp.sdk;


public enum EventCode {
    ThrottledReceived,
    QueueFullReceieved;
}
