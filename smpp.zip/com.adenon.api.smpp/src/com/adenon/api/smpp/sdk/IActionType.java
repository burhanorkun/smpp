package com.adenon.api.smpp.sdk;


public interface IActionType {

    public int getValue();
}
