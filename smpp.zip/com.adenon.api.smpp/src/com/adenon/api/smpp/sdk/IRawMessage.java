package com.adenon.api.smpp.sdk;


public interface IRawMessage {

    public byte[] getBytes();
}
