package com.adenon.api.smpp.sdk;

import java.util.List;


public interface IRawMessages {

    List<IRawMessage> getMessageList();

}
