package com.adenon.api.smpp.message;


public interface MessageObject {

    public int getMesssageType();

    public String getDescription();
}
