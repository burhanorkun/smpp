package com.adenon.api.smpp.connection;


public enum EConnectionStateChange {
    RESTART,
    SUSPEND,
    UNSUSPEND,
    SHUTDOWN,
    BIND,
    UNBIND;
}
