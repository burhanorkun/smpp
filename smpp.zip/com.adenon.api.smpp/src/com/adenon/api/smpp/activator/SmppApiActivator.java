// package com.adenon.api.smpp.activator;
//
// import org.osgi.framework.BundleActivator;
// import org.osgi.framework.BundleContext;
//
// public class SmppApiActivator implements BundleActivator {
//
// @Override
// public void start(BundleContext context) throws Exception {
// }
//
// @Override
// public void stop(BundleContext context) throws Exception {
// }
//
// }
