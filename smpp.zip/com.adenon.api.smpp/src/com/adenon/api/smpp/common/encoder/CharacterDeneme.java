package com.adenon.api.smpp.common.encoder;

public class CharacterDeneme {

    public static void main(final String[] args) {
        // for (int i = 0; i < a.length(); i++) {
        // char c = a.charAt(i);
        // byte[] m = new byte[2];
        // m[0] = (byte) ((0xFF00 & c) >> 8);
        // m[1] = (byte) (0x00FF & c);
        // System.out.println("Character = " + c + " byte : " + CommonUtils.bytesToHex(m));
        // }
    }
}
